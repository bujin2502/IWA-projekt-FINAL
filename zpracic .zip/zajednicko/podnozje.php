</body>
<footer>
  <br><p>&copy Zlatko Pračić | <a href="mailto:zpracic@foi.hr">zpracic@foi.hr</a> | <?php echo date("Y");?></p><br>
</footer>
</html>

